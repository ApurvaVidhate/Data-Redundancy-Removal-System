from flask import Flask, render_template, redirect, url_for
import sqlite3

app = Flask(__name__)
highlight_ids = set()

def get_all_students():
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute("SELECT * FROM students")
    data = c.fetchall()
    conn.close()
    return data

@app.route('/')
def index():
    students = get_all_students()
    return render_template('index.html', students=students, highlights=highlight_ids)

@app.route('/check_data')
def check_data():
    global highlight_ids
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute('''
        SELECT id FROM students
        WHERE (name, roll_no, class_, branch) IN (
            SELECT name, roll_no, class_, branch
            FROM students
            GROUP BY name, roll_no, class_, branch
            HAVING COUNT(*) > 1
        )
        ORDER BY id
    ''')
    duplicates = c.fetchall()
    conn.close()

    highlight_ids = set()
    if len(duplicates) > 1:
        highlight_ids.add(duplicates[1][0])  # highlight second duplicate
    return redirect(url_for('index'))

@app.route('/remove_duplicates')
def remove_duplicates():
    global highlight_ids
    conn = sqlite3.connect('students.db')
    c = conn.cursor()

    # Find duplicates again
    c.execute('''
        SELECT id FROM students
        WHERE (name, roll_no, class_, branch) IN (
            SELECT name, roll_no, class_, branch
            FROM students
            GROUP BY name, roll_no, class_, branch
            HAVING COUNT(*) > 1
        )
        ORDER BY id
    ''')
    duplicates = c.fetchall()
    if len(duplicates) > 1:
        c.execute("DELETE FROM students WHERE id = ?", (duplicates[1][0],))
        conn.commit()
    conn.close()
    highlight_ids = set()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
