import sqlite3

# Initialize database with duplicate data
conn = sqlite3.connect('students.db')
c = conn.cursor()

# Create table
c.execute('''
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    roll_no TEXT,
    class_ TEXT,
    branch TEXT
)
''')

# Clear previous data
c.execute("DELETE FROM students")

# Insert fresh data (with 1 duplicate)
students = [
    ('Vijay', '1', 'FY', 'CSE'),
    ('Aditya', '2', 'SY', 'ECE'),
    ('Neha', '3', 'TY', 'EEE'),
    ('Atharv', '4', 'TY', 'MECH'),
    ('Khushi', '5', 'SY', 'CIVIL'),
    ('Vijay', '1', 'FY', 'CSE')  # duplicate
]

c.executemany("INSERT INTO students (name, roll_no, class_, branch) VALUES (?, ?, ?, ?)", students)

conn.commit()
conn.close()

print("Database initialized with 1 duplicate.")
